# EverGuard Demo (GitHub Pages)

This is the EverGuard Systems demo (single-file HTML).

## Quick deploy on GitHub Pages
1. Create a new repo (e.g., `everguard-demo`) under your GitHub user or org (e.g., `everguardlocks`).
2. Upload `index.html` to the root of the repo and commit.
3. Go to **Settings → Pages**:
   - **Build and deployment** → *Source*: **Deploy from a branch**
   - **Branch**: **main** / **/(root)**
   - Click **Save**.
4. After it builds, your link will be: `https://<username-or-org>.github.io/<repo>/`

Example for org `everguardlocks` and repo `everguard-demo`:  
`https://everguardlocks.github.io/everguard-demo/`